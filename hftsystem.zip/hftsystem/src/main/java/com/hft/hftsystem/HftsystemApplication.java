package com.hft.hftsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HftsystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(HftsystemApplication.class, args);
	}

}
