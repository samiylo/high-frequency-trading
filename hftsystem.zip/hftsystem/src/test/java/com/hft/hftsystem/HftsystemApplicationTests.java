package com.hft.hftsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HftsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
